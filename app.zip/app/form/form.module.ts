import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatCardModule,MatInputModule, MatFormFieldModule, MatButtonModule } from '@angular/material';
import { FlexLayoutModule } from "@angular/flex-layout";

import { NgSelectModule, NG_SELECT_DEFAULT_CONFIG } from '@ng-select/ng-select';
import { ReactiveFormsModule , FormsModule } from '@angular/forms';

import { DataService } from './data.service';

import { FormRoutingModule } from './form-routing.module';
import { FormComponent } from './form.component';

@NgModule({
  imports: [
    CommonModule,
    FormRoutingModule,
    MatInputModule,MatCardModule,MatButtonModule,
    FlexLayoutModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
        DataService,
        {
            provide: NG_SELECT_DEFAULT_CONFIG,
            useValue: {
                placeholder: 'Select item',
                notFoundText: 'Items not found',
                addTagText: 'Add item',
                typeToSearchText: 'Type to search',
                loadingText: 'Loading...',
                clearAllText: 'Clear all'
            }
        }
      ],
  declarations: [FormComponent]
})
export class FormModule { }
