import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormcloneRoutingModule } from './formclone-routing.module';
import { FormcloneComponent } from './formclone.component';

@NgModule({
  imports: [
    CommonModule,
    FormcloneRoutingModule
  ],
  declarations: [FormcloneComponent]
})
export class FormcloneModule { }
