import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormcloneComponent } from './formclone.component';

describe('FormcloneComponent', () => {
  let component: FormcloneComponent;
  let fixture: ComponentFixture<FormcloneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormcloneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormcloneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
