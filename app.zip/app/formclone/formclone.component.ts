import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formclone',
  templateUrl: './formclone.component.html',
  styleUrls: ['./formclone.component.css']
})
export class FormcloneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
