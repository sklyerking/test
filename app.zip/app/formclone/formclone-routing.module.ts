import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FormcloneComponent } from './formclone.component';

const routes: Routes = [
  {
    path: '',
    component: FormcloneComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormcloneRoutingModule { }
