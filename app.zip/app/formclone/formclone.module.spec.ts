import { FormcloneModule } from './formclone.module';

describe('FormcloneModule', () => {
  let formcloneModule: FormcloneModule;

  beforeEach(() => {
    formcloneModule = new FormcloneModule();
  });

  it('should create an instance', () => {
    expect(formcloneModule).toBeTruthy();
  });
});
